from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(seasions)

admin.site.register(titels)
admin.site.register(description)
admin.site.register(question)
admin.site.register(dq)